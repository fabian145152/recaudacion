<?php
require_once __DIR__ . '/../funciones/auth.php';
requireLogin();

include_once "../funciones/funciones.php";

$con = conexion();
$con->set_charset("utf8mb4");

// === AUTO-MIGRACIÓN (por si no se corrió el SQL) ===
$check1 = $con->query("SHOW COLUMNS FROM recauda LIKE 'registrado_por'");
if ($check1 && $check1->num_rows === 0) {
    $con->query("ALTER TABLE recauda ADD COLUMN registrado_por VARCHAR(100) DEFAULT NULL");
}
$check2 = $con->query("SHOW COLUMNS FROM recauda LIKE 'registrado_fecha'");
if ($check2 && $check2->num_rows === 0) {
    $con->query("ALTER TABLE recauda ADD COLUMN registrado_fecha DATETIME DEFAULT NULL");
}

function limpiar($v)
{
    return htmlspecialchars(trim($v), ENT_QUOTES, 'UTF-8');
}

function subirFoto($inputName, $dir = "../images/")
{
    if (!isset($_FILES[$inputName]) || $_FILES[$inputName]['error'] !== UPLOAD_ERR_OK) return null;
    $permitidos = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
    if (!in_array(mime_content_type($_FILES[$inputName]['tmp_name']), $permitidos)) return null;
    $ext = pathinfo(basename($_FILES[$inputName]['name']), PATHINFO_EXTENSION);
    $nuevo = uniqid("foto_", true) . "." . strtolower($ext);
    return move_uploaded_file($_FILES[$inputName]['tmp_name'], $dir . $nuevo) ? $nuevo : null;
}

// === CAPTURAR DATOS DEL FORM ===
$turno        = strtoupper(limpiar($_POST['turno'] ?? ''));
$movil        = (int)($_POST['movil'] ?? 0);
$chofer_id    = (int)($_POST['chofer_id'] ?? 0);
$vehiculo_id  = (int)($_POST['vehiculo_id'] ?? 0); // Ahora se mantiene como entero (0 por defecto)
$fecha        = limpiar($_POST['fecha'] ?? date("Y-m-d"));
$sin_auto     = isset($_POST['sin_auto']) && $_POST['sin_auto'] === '1';

$observaciones = trim($_POST['observaciones'] ?? '');
$modo_edicion = isset($_POST['modo_edicion']) && $_POST['modo_edicion'] == '1';

$abono_diario     = floatval($_POST['abono_diario'] ?? 0);
$voucher_nuevo    = floatval($_POST['voucher_nuevo'] ?? 0);
$porcentaje_nuevo = floatval($_POST['porcentaje_nuevo'] ?? 10);
$mp_nuevo         = floatval($_POST['mp_nuevo'] ?? 0);
$ft_nuevo         = floatval($_POST['ft_nuevo'] ?? 0);

// === QUIÉN Y CUÁNDO ===
$usuario_nombre = $_SESSION['nombre'] ?? ($_SESSION['usuario'] ?? 'Desconocido');
$ahora = date('Y-m-d H:i:s');

// === VALIDACIONES ===
if (empty($chofer_id)) die("Error: Falta el chofer.");
if (empty($turno)) $turno = 'DIA';
if (!in_array($turno, ['DIA', 'NOCHE'])) $turno = 'DIA';
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha)) $fecha = date("Y-m-d");

// === LEER VALORES ACTUALES ===
$stmt = $con->prepare("SELECT voucher, porcent, comision, total, mp, ft, paga, abono_diario, observaciones FROM recauda WHERE fecha = ? AND chofer_id = ? LIMIT 1");
$stmt->bind_param("si", $fecha, $chofer_id);
$stmt->execute();
$reca_actual = $stmt->get_result()->fetch_assoc();
$stmt->close();

$voucher_prev      = floatval($reca_actual['voucher'] ?? 0);
$mp_prev           = floatval($reca_actual['mp'] ?? 0);
$ft_prev           = floatval($reca_actual['ft'] ?? 0);
$abono_diario_prev = floatval($reca_actual['abono_diario'] ?? 0);
$obs_prev          = trim($reca_actual['observaciones'] ?? '');

if (!array_key_exists('abono_diario', $_POST) && $abono_diario_prev > 0) {
    $abono_diario = $abono_diario_prev;
}

if (!$modo_edicion && $observaciones === '' && $obs_prev !== '') {
    $observaciones = $obs_prev;
}

// === SUMAR O REEMPLAZAR ===
if ($modo_edicion) {
    $voucher_total = $voucher_nuevo;
    $mp_total      = $mp_nuevo;
    $ft_total      = $ft_nuevo;
} else {
    $voucher_total = $voucher_prev + $voucher_nuevo;
    $mp_total      = $mp_prev + $mp_nuevo;
    $ft_total      = $ft_prev + $ft_nuevo;
}

$porcentaje_final = 10;
$comision_final = $voucher_total * $porcentaje_final / 100;
$total_final    = $voucher_total - $comision_final;

$deposito = $total_final + $mp_total + $ft_total;
$debe_final = $abono_diario - $deposito;

// === SUBIR FOTO ===
$foto = subirFoto("foto_chofer");
if ($foto) {
    $stmt = $con->prepare("UPDATE choferes SET foto=? WHERE id=?");
    $stmt->bind_param("si", $foto, $chofer_id);
    $stmt->execute();
    $stmt->close();
}

$con->begin_transaction();
try {
    // === INSERT / UPDATE CON TRACKING DE USUARIO ===
    $stmt = $con->prepare("
        INSERT INTO recauda 
        (fecha, chofer_id, vehiculo_id, movil, turno, abono_diario, paga, voucher, porcent, comision, total, mp, ft, debe, observaciones, registrado_por, registrado_fecha)
        VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            vehiculo_id  = VALUES(vehiculo_id),
            movil        = VALUES(movil),
            turno        = VALUES(turno),
            abono_diario = VALUES(abono_diario),
            voucher      = VALUES(voucher),
            porcent      = VALUES(porcent),
            comision     = VALUES(comision),
            total        = VALUES(total),
            mp           = VALUES(mp),
            ft           = VALUES(ft),
            debe         = VALUES(debe),
            observaciones= VALUES(observaciones),
            registrado_por = VALUES(registrado_por),
            registrado_fecha = VALUES(registrado_fecha)
    ");

    if (!$stmt) {
        throw new Exception("Error al preparar la consulta: " . $con->error);
    }

    // CADENA CORREGIDA: "siiisddddddddsss" (16 caracteres para 16 variables)
    $stmt->bind_param(
        "siiisddddddddsss",
        $fecha,
        $chofer_id,
        $vehiculo_id,
        $movil,
        $turno,
        $abono_diario,
        $voucher_total,
        $porcentaje_final,
        $comision_final,
        $total_final,
        $mp_total,
        $ft_total,
        $debe_final,
        $observaciones,
        $usuario_nombre,
        $ahora
    );

    if (!$stmt->execute()) {
        throw new Exception("Error SQL al guardar la recaudación: " . $stmt->error);
    }
    $stmt->close();

    // === OBTENER ID DE LA RECAUDA ===
    $stmt = $con->prepare("SELECT id FROM recauda WHERE fecha = ? AND chofer_id = ? LIMIT 1");
    if (!$stmt) {
        throw new Exception("Error al buscar el ID (Verificá si tu tabla tiene una columna 'id'): " . $con->error);
    }
    $stmt->bind_param("si", $fecha, $chofer_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row) throw new Exception("No se encontró la recauda recién guardada.");
    $recauda_id = (int)$row['id'];

    // === ACTUALIZAR CUENTA CORRIENTE ===
    $stmt = $con->prepare("SELECT id FROM cuenta_corriente WHERE chofer_id = ? AND fecha = ? AND (tipo = 'DEUDA' OR tipo = 'A CUENTA')");
    $stmt->bind_param("is", $chofer_id, $fecha);
    $stmt->execute();
    $cc_existente = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (abs($debe_final) > 0.001) {
        if ($debe_final > 0) {
            $tipo = 'DEUDA';
            $monto_cc = -$debe_final;
            $descripcion = "Quedó debiendo del turno $turno del $fecha";
        } else {
            $tipo = 'A CUENTA';
            $monto_cc = -$debe_final;
            $descripcion = "A cuenta del turno $turno del $fecha";
        }

        if ($cc_existente) {
            $stmt = $con->prepare("UPDATE cuenta_corriente SET monto = ?, tipo = ?, descripcion = ?, recauda_id = ? WHERE id = ?");
            $stmt->bind_param("dssii", $monto_cc, $tipo, $descripcion, $recauda_id, $cc_existente['id']);
            $stmt->execute();
            $stmt->close();
        } else {
            $stmt = $con->prepare("INSERT INTO cuenta_corriente (chofer_id, fecha, monto, tipo, descripcion, recauda_id) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("isdssi", $chofer_id, $fecha, $monto_cc, $tipo, $descripcion, $recauda_id);
            $stmt->execute();
            $stmt->close();
        }
    } else {
        if ($cc_existente) {
            $stmt = $con->prepare("DELETE FROM cuenta_corriente WHERE id = ?");
            $stmt->bind_param("i", $cc_existente['id']);
            $stmt->execute();
            $stmt->close();
        }
    }

    $con->commit();

    $stmt_nombre = $con->prepare("SELECT nombre FROM choferes WHERE id = ?");
    $stmt_nombre->bind_param("i", $chofer_id);
    $stmt_nombre->execute();
    $row_chofer = $stmt_nombre->get_result()->fetch_assoc();
    $nombre_chofer = $row_chofer ? $row_chofer['nombre'] : 'Desconocido';
    $stmt_nombre->close();

    $nueva_redirect = (isset($_POST['nueva']) && $_POST['nueva'] == '1') ? '&nueva=1' : '';
    $fecha_url = urlencode($fecha);
    $fmt_deposito = number_format($deposito, 2, ',', '.');
    $fmt_abono = number_format($abono_diario, 2, ',', '.');
    $fecha_mostrar = date('d/m/Y', strtotime($fecha));

    $msj = $modo_edicion ? 'Importes corregidos' : 'Datos guardados';
    $texto_obs = !empty($observaciones) ? "\\nObservaciones: " . addslashes($observaciones) : "";

    echo "<script>
        var confirmar = confirm('✅ $msj correctamente.\\n\\nFecha: $fecha_mostrar\\nChofer: $nombre_chofer\\nAbono esperado: \\$$fmt_abono\\nTotal Depositado: \\$$fmt_deposito$texto_obs\\n\\n¿Confirmás que los datos son correctos?');
        if (confirmar) {
            window.location='cargar_selector.php?fecha=$fecha_url$nueva_redirect';
        } else {
            window.history.back();
        }
    </script>";
} catch (Exception $e) {
    $con->rollback();
    $error_msg = addslashes($e->getMessage());
    echo "<script>alert('❌ Error: $error_msg'); window.history.back();</script>";
}

$con->close();
